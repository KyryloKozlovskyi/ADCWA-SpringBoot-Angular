import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

export interface Vehicle {
  reg: string;
  make: string;
  model: string;
  owner: {
    cid: string;
    name: string;
  };
  mechanic: {
    mid: string;
    name: string;
    salary: number;
    garage: {
      gid: string;
      location: string;
      budget: number;
    };
  };
}

@Injectable({
  providedIn: 'root',
})
export class VehicleService {
  private baseUrl = 'http://localhost:8080/api/vehicle';

  constructor(private http: HttpClient) {}

  getAllVehicles(): Observable<Vehicle[]> {
    return this.http
      .get<Vehicle[]>(`${this.baseUrl}/all`)
      .pipe(catchError(this.handleError));
  }

  getVehicleByReg(reg: string): Observable<Vehicle> {
    // Since there's no direct endpoint for getting a single vehicle,
    // we'll get all vehicles and filter by reg
    return new Observable<Vehicle>((observer) => {
      this.getAllVehicles().subscribe({
        next: (vehicles) => {
          const vehicle = vehicles.find((v) => v.reg === reg);
          if (vehicle) {
            observer.next(vehicle);
            observer.complete();
          } else {
            observer.error({
              error: `Vehicle with registration ${reg} not found`,
            });
          }
        },
        error: (err) => observer.error(err),
      });
    });
  }

  updateVehicleMechanic(reg: string, mid: string): Observable<any> {
    return this.http
      .put(`${this.baseUrl}/${reg}`, { mid })
      .pipe(catchError(this.handleError));
  }

  private handleError(error: HttpErrorResponse) {
    console.error('API Error:', error);
    return throwError(() => error);
  }
}
